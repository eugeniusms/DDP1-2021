import string
import html_functions

# Menginisiasi variabel kosong
filter_kata = []
file_masukan = ""
file_keluaran = ""
jumlah_kata = []
data_terbanyak = []
data_final = []
lst_kata = []

def inisiasi_program():
    # Fungsi untuk mengawali jalannya program seperti mengambil input
    global kata, file_masukan, file_keluaran
    # Mencari file masukan ke dalam program
    print("Program untuk membuat word cloud dari text file\n---------------------------------------------")
    print("hasilnya disimpan sebagai file html,\nyang bisa ditampilkan di browser.\n\n")
    file_masukan = input("Silakan masukan nama file: ")
    file_keluaran = file_masukan + ".html"
    print("\n\n"+file_masukan)
    print("56 kata diurutkan berdasarkan jumlah kemunculan dalam pasangan\n(jumlah:kata)\n\n")

    # Membaca file ke dalam suatu variabel untuk dioperasikan
    file_input = open(file_masukan)
    isi_file = file_input.read()
    file_input.close()

    # Mengecilkan huruf pada paragraf agar pencarian dan pencocokan lebih mudah
    isi_file = isi_file.lower()
    kata = isi_file.split()

def tanda_baca(kata):
    # Fungsi untuk menghilangkan tanda baca di bagian awal dan belakang kata
    punc = []

    # Mencari indeks tanda baca dari depan kata
    for i in range(len(kata)):
        if kata[i] in string.punctuation:
            punc.append(i)
        else:
            break

    # Mencari indeks tanda baca dari belakang kata
    i = len(kata) - 1
    while i >= 0:
        if kata[i] in string.punctuation:
            punc.append(i)
        else:
            break
        i -= 1

    # Menghilangkan karakter tanda baca sesuai indeks yang didapati
    char_kata = []
    # Memisahkan huruf dalam kata untuk dimasukkan ke dalam list
    for i in range(len(kata)):
        char_kata.append(kata[i])
    # Untuk indeks yang terdapat dalam punc maka hapus isi list char_kata di inedks tersebut
    for i in punc:
        char_kata[i] = ""
    # Menggabungkan karakter dalam list menjadi bentuk string lagi
    hasil = "".join(str(char_kata[i]) for i in range(len(char_kata)))
    return hasil

def stopwords(kata_unik):
    # Fungsi untuk menghapus stopwords yang terdapat dalam daftar kata
    global filter_kata

    # Membaca file stopwords dan membaginya ke dalam list
    file_input = open("stopwords.txt")
    stopwords = file_input.read()
    stopwords = stopwords.split()

    # Mengecek apakah kata ada di dalam stopwords
    for kata in kata_unik:
        cek = 0
        # Jika kata terdapat dalam stopwords maka (cek=1) untuk menandai
        for kata_stop in stopwords:
            if kata == kata_stop:
                cek += 1
        # Jika tidak terdapat kata pada stopwords (cek=0) maka tambahkan ke daftar list 
        if cek == 0:
            filter_kata.append(kata)

def hitung_kata(filter_kata):
    # Fungsi untuk mencari jumlah kata pada isi file yang sudah filter
    global jumlah_kata

    # Mencari jumlah dari tiap kata lalu menambahkannya ke dalam suatu list
    for kata in filter_kata:
        hitung = lst_kata.count(kata)
        jumlah_kata.append(hitung)

def kata_terbanyak(jumlah_kata):
    # Fungsi untuk mengurutkan isi list sesuai jumlah kata yang muncul
    global data_terbanyak
    # Mencari terbesar terus append and remove sebanyak 56 kali
    for i in range(56):
        data_dimensi = []
        # Mencari terbesar sementara dan indeks sementara
        terbesar = max(jumlah_kata)
        indeks_terbesar = jumlah_kata.index(terbesar)

        # Memasukkan data terbesar sementara ke dalam list
        data_dimensi.append(filter_kata[indeks_terbesar])
        data_dimensi.append(terbesar)
        # Membuat list dua dimensi dari 2 masukan 
        data_terbanyak.append(data_dimensi)

        # Mereset angka yang sudah terpakai di jumlah_kata agar tidak terulang
        jumlah_kata[indeks_terbesar] = -1

def tampilan(data_terbanyak):
    # Fungsi untuk menampilkan data di terminal tentang urutan kata terbanyak
    lst_kata = []

    # Mencari angka terbesar data sudah urut untuk dicari len (panjang digitnya)
    maksimal = data_terbanyak[0][1]
    len_maks = len(str(maksimal))

    # Menyusun list yang akan dipanggil untuk penyusunan kolom dengan pembentukan string
    terpanjang = 0
    for kata in data_terbanyak:
        # Cek jumlah digit angka dan menghitung spasi dibutuhkan
        len_jumlah = len(str(kata[1]))
        spasi = len_maks - len_jumlah

        # Menyusun bentuk string untuk tiap output terminal
        kata = " "*spasi + str(kata[1]) + ":" + str(kata[0])
        lst_kata.append(kata)

        # Menghitung kemungkinan kata terpanjang di dalam list data_terbanyak
        panjang = len(kata)
        if panjang > terpanjang:
            terpanjang = panjang

    # Membuat cetakan dari input yang sudah didapat di atas ke dalam sebuah terminal
    for i in range(len(lst_kata)):
        # Setiap 4 data maka lakukan ganti baris end = "\n" implisit
        if (i + 1) % 4 == 0:
            print(f"{lst_kata[i]:<{terpanjang + 4}}")
        else:
            print(f"{lst_kata[i]:<{terpanjang + 4}}", end = "")

    # Membuat penerimaan input untuk akhir terminal dari program
    enter = input("\n\nTekan Enter untuk keluar …")
    if enter == "":
        print()

def urutkan_huruf(data_terbanyak):
    # Fungsi untuk mengurutkan semua data yang sudah didapat melalui huruf abjadnya
    global data_final
    data_kata = ""

    # Memasukan data ke dalam string untuk diambil katanya saja
    for i in range(56):
        data_kata += " " + data_terbanyak[i][0]
        
    # Mengurutkan kata berdasar abjad dalam bentuk list
    data_kata = data_kata.split()
    data_kata.sort()

    # Menginisasi isi data_terbanyak_dimensi1 -> 1 dimensi lebih sederhana untuk dioperasikan
    data_terbanyak_dimensi1 = []

    # Mengambil data dalam list 2 dimensi ke dalam list 1 dimensi
    for i in range(56):
        masukan_kata = data_terbanyak[i][0]
        masukan_jumlah = data_terbanyak[i][1]
        data_terbanyak_dimensi1.append(masukan_kata)
        data_terbanyak_dimensi1.append(masukan_jumlah)

    # Mencari indeks dari tiap kata yang sudah disorting untuk dipanggil jumlahnya di indeks setelah kata tersebut (dalam list 1 dimensi)
    for kata in data_kata:
        indeks_kata = data_terbanyak_dimensi1.index(kata)
        # Memasukkan kembali data yang sudah diurutkan berdasarkan abjad dan jumlahnya
        data_final.append(kata)
        data_final.append(data_terbanyak_dimensi1[indeks_kata + 1])

def membuat_file(data_final):
    # Fungsi untuk membuat file HTML
    body = ""
    data_count = []

    # Memasukkan nilai dari jumlah tiap kata ke dalam list data_count
    for i in range(len(data_final)):
        if i % 2 == 1:
            data_count.append(data_final[i])

    hitung_program =  0
    # Menjalankan perulangan selama hitung programnya di bawah 56 * 2 (sebanyak total isi list data_final)
    while hitung_program < 56*2:
        # Mencari atribut dengan pencarian nilai yang ada
        word = data_final[hitung_program]
        cnt = float(data_final[hitung_program + 1])
        high_count =float(max(data_count))
        low_count = float(min(data_count))

        # Memanggil fungsi untuk membentuk sebuah body HTML
        body = body + " " + html_functions.make_HTML_word(word, cnt, high_count, low_count)

        # Menambah dua setiap perulangan agar berpasangan antara kata dan jumlah katanya
        hitung_program += 2

    # Memanggul fungsi box untuk body yang sudah didapat dan menjalankan fungsi print_HTML_file
    body = html_functions.make_HTML_box(body)
    html_functions.print_HTML_file(body, "A Word Cloud of "+file_masukan[:-4])


def main():
    # Fungsi utama untuk menjalankan program
    global lst_kata, kata

    # Memulai awal program dengan inisiasi program
    inisiasi_program()

    # Memanggil fungsi penghilang tanda baca di awal dan akhir kata untuk setiap kata dalam list
    for kata in kata:
        lst_kata.append(tanda_baca(kata))

    # Memanggil set (himpunan) untuk mendapat kata unik dari lst_kata
    kata_unik = list(set(lst_kata))

    # Menjalankan fungsi operasi untuk program
    stopwords(kata_unik)
    hitung_kata(filter_kata)
    kata_terbanyak(jumlah_kata)
    tampilan(data_terbanyak)
    urutkan_huruf(data_terbanyak)

    # Memanggil fungsi untuk membuat file HTML
    membuat_file(data_final)

# Memulai program dengan memanggil fungsi operasi utama normal dari program
main()